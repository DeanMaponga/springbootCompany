package com.example.companyRegister;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompanyRegisterApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompanyRegisterApplication.class, args);
	}

}
